import {
  integer,
  numeric,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

export const bountyStatusEnum = pgEnum("bounty_status", [
  "draft",
  "funding_pending",
  "in_escrow",
  "revision_needed",
  "payout_processing",
  "payout_failed",
  "paid",
]);

export const bounties = pgTable("bounties", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: varchar("title", { length: 180 }).notNull(),
  requirements: text("requirements").notNull(),
  reward: numeric("reward", { precision: 10, scale: 2 }).notNull(),
  freelancerEmail: varchar("freelancer_email", { length: 254 }).notNull(),
  status: bountyStatusEnum("status").default("draft").notNull(),
  paypalOrderId: varchar("paypal_order_id", { length: 128 }),
  paypalCaptureId: varchar("paypal_capture_id", { length: 128 }),
  paypalPayoutBatchId: varchar("paypal_payout_batch_id", { length: 128 }),
  paypalPayoutItemId: varchar("paypal_payout_item_id", { length: 128 }),
  paypalPayoutRequestId: varchar("paypal_payout_request_id", { length: 128 }),
  payoutError: text("payout_error"),
  submission: text("submission"),
  aiScore: integer("ai_score"),
  aiFeedback: text("ai_feedback"),
  aiSummary: text("ai_summary"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export type Bounty = typeof bounties.$inferSelect;
export type NewBounty = typeof bounties.$inferInsert;
