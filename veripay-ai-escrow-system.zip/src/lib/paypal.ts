import type { Bounty } from "@/db/schema";

const SANDBOX_API = "https://api-m.sandbox.paypal.com";

type PayPalTokenResponse = {
  access_token: string;
  expires_in: number;
};

type PayPalOrder = {
  id: string;
  status: string;
  purchase_units?: Array<{
    reference_id?: string;
    custom_id?: string;
    payments?: {
      captures?: Array<{
        id: string;
        status: string;
        amount?: { currency_code?: string; value?: string };
      }>;
    };
  }>;
};

type PayPalPayoutResponse = {
  batch_header?: {
    payout_batch_id?: string;
    batch_status?: string;
  };
  items?: Array<{ payout_item_id?: string }>;
};

type PayPalErrorBody = {
  message?: string;
  error_description?: string;
  name?: string;
  details?: Array<{ issue?: string; description?: string }>;
};

export class PayPalApiError extends Error {
  constructor(
    message: string,
    public readonly status: number,
  ) {
    super(message);
    this.name = "PayPalApiError";
  }
}

function apiBase() {
  return (process.env.PAYPAL_API_BASE || SANDBOX_API).replace(/\/$/, "");
}

function credentials() {
  const clientId = process.env.PAYPAL_CLIENT_ID;
  const clientSecret = process.env.PAYPAL_CLIENT_SECRET;
  if (!clientId || !clientSecret) {
    throw new Error("PayPal is not configured. Add PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET.");
  }
  return { clientId, clientSecret };
}

async function responseError(response: Response) {
  const text = await response.text();
  let message = `PayPal request failed (${response.status}).`;
  if (text) {
    try {
      const payload = JSON.parse(text) as PayPalErrorBody;
      message =
        payload.message ||
        payload.error_description ||
        payload.details?.map((detail) => detail.description || detail.issue).filter(Boolean).join("; ") ||
        payload.name ||
        message;
    } catch {
      message = text.slice(0, 500) || message;
    }
  }
  return new PayPalApiError(message, response.status);
}

export async function getPayPalAccessToken() {
  const { clientId, clientSecret } = credentials();
  const response = await fetch(`${apiBase()}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString("base64")}`,
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json",
    },
    body: "grant_type=client_credentials",
    cache: "no-store",
  });

  if (!response.ok) throw await responseError(response);
  const payload = (await response.json()) as PayPalTokenResponse;
  if (!payload.access_token) throw new Error("PayPal did not return an access token.");
  return payload;
}

async function paypalJson<T>(path: string, init: RequestInit = {}) {
  const { access_token } = await getPayPalAccessToken();
  const response = await fetch(`${apiBase()}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${access_token}`,
      "Content-Type": "application/json",
      Accept: "application/json",
      ...init.headers,
    },
    cache: "no-store",
  });
  if (!response.ok) throw await responseError(response);
  return (await response.json()) as T;
}

export function formatUsd(value: string | number) {
  const amount = Number(value);
  if (!Number.isFinite(amount) || amount <= 0) {
    throw new Error("The bounty reward must be a positive USD amount.");
  }
  return amount.toFixed(2);
}

export async function createPayPalOrder(bounty: Bounty) {
  return paypalJson<PayPalOrder>("/v2/checkout/orders", {
    method: "POST",
    headers: { "PayPal-Request-Id": `veripay-order-${bounty.id}` },
    body: JSON.stringify({
      intent: "CAPTURE",
      purchase_units: [
        {
          reference_id: bounty.id,
          custom_id: bounty.id,
          description: bounty.title.slice(0, 127),
          amount: { currency_code: "USD", value: formatUsd(bounty.reward) },
        },
      ],
      application_context: {
        brand_name: "VeriPay AI",
        user_action: "PAY_NOW",
        shipping_preference: "NO_SHIPPING",
      },
    }),
  });
}

export async function capturePayPalOrder(orderId: string) {
  return paypalJson<PayPalOrder>(`/v2/checkout/orders/${encodeURIComponent(orderId)}/capture`, {
    method: "POST",
    headers: { "PayPal-Request-Id": `veripay-capture-${orderId}` },
    body: "{}",
  });
}

export function newPayoutRequestId() {
  return `vp-${crypto.randomUUID().replaceAll("-", "").slice(0, 26)}`;
}

export async function createPayPalPayout(bounty: Bounty, requestId: string) {
  const payload = await paypalJson<PayPalPayoutResponse>("/v1/payments/payouts", {
    method: "POST",
    headers: { "PayPal-Request-Id": requestId },
    body: JSON.stringify({
      sender_batch_header: {
        sender_batch_id: requestId,
        email_subject: "Your VeriPay AI freelance payout is on its way",
        email_message: `Your work on “${bounty.title}” has been approved.`,
      },
      items: [
        {
          recipient_type: "EMAIL",
          amount: { value: formatUsd(bounty.reward), currency: "USD" },
          receiver: bounty.freelancerEmail,
          note: `VeriPay AI bounty: ${bounty.title}`.slice(0, 400),
          sender_item_id: bounty.id,
        },
      ],
    }),
  });

  const batchId = payload.batch_header?.payout_batch_id;
  if (!batchId) throw new Error("PayPal accepted no payout batch ID in its response.");
  return {
    batchId,
    itemId: payload.items?.[0]?.payout_item_id ?? null,
    batchStatus: payload.batch_header?.batch_status ?? "PENDING",
  };
}
