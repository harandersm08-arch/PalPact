export type BountyStatus =
  | "draft"
  | "funding_pending"
  | "in_escrow"
  | "revision_needed"
  | "payout_processing"
  | "payout_failed"
  | "paid";

export type DashboardView = "client" | "freelancer";

export type Bounty = {
  id: string;
  title: string;
  requirements: string;
  reward: string;
  freelancerEmail: string;
  status: BountyStatus;
  paypalOrderId: string | null;
  paypalCaptureId: string | null;
  paypalPayoutBatchId: string | null;
  paypalPayoutItemId: string | null;
  paypalPayoutRequestId: string | null;
  payoutError: string | null;
  submission: string | null;
  aiScore: number | null;
  aiFeedback: string | null;
  aiSummary: string | null;
  createdAt: string;
  updatedAt: string;
};
