import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { bounties, type Bounty } from "@/db/schema";
import { createPayPalPayout, newPayoutRequestId } from "@/lib/paypal";
import { notifyZapierOfPayout } from "@/lib/zapier";

export async function claimApprovedBounty(
  bountyId: string,
  details: { score: number; feedback: string; summary: string; submission: string },
) {
  const [claimed] = await db
    .update(bounties)
    .set({
      status: "payout_processing",
      aiScore: details.score,
      aiFeedback: details.feedback,
      aiSummary: details.summary,
      submission: details.submission,
      paypalPayoutRequestId: newPayoutRequestId(),
      payoutError: null,
      updatedAt: new Date(),
    })
    .where(
      and(
        eq(bounties.id, bountyId),
        inArray(bounties.status, ["in_escrow", "revision_needed"]),
      ),
    )
    .returning();

  return claimed ?? null;
}

export async function claimFailedPayout(bountyId: string) {
  const [current] = await db.select().from(bounties).where(eq(bounties.id, bountyId)).limit(1);
  if (!current || current.status !== "payout_failed" || (current.aiScore ?? 0) < 80) {
    return null;
  }

  const [claimed] = await db
    .update(bounties)
    .set({
      status: "payout_processing",
      paypalPayoutRequestId: current.paypalPayoutRequestId || newPayoutRequestId(),
      payoutError: null,
      updatedAt: new Date(),
    })
    .where(and(eq(bounties.id, bountyId), eq(bounties.status, "payout_failed")))
    .returning();

  return claimed ?? null;
}

export async function executeClaimedPayout(bounty: Bounty) {
  if (bounty.status !== "payout_processing" || !bounty.paypalPayoutRequestId) {
    throw new Error("This bounty does not have a claimed PayPal payout.");
  }

  let payout: Awaited<ReturnType<typeof createPayPalPayout>>;
  try {
    payout = await createPayPalPayout(bounty, bounty.paypalPayoutRequestId);
  } catch (error) {
    const message = error instanceof Error ? error.message : "PayPal payout could not be completed.";
    await db
      .update(bounties)
      .set({ status: "payout_failed", payoutError: message, updatedAt: new Date() })
      .where(and(eq(bounties.id, bounty.id), eq(bounties.status, "payout_processing")));
    throw error;
  }

  const [completed] = await db
    .update(bounties)
    .set({
      status: "paid",
      paypalPayoutBatchId: payout.batchId,
      paypalPayoutItemId: payout.itemId,
      payoutError: null,
      updatedAt: new Date(),
    })
    .where(and(eq(bounties.id, bounty.id), eq(bounties.status, "payout_processing")))
    .returning();

  if (!completed) {
    const [latest] = await db.select().from(bounties).where(eq(bounties.id, bounty.id)).limit(1);
    if (latest?.status === "paid") return latest;
    throw new Error("PayPal accepted the payout, but the bounty status could not be updated.");
  }

  await notifyZapierOfPayout(completed);
  return completed;
}
