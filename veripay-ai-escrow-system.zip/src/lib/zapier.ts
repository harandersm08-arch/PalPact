import type { Bounty } from "@/db/schema";

export async function notifyZapierOfPayout(bounty: Bounty) {
  const webhookUrl = process.env.ZAPIER_WEBHOOK_URL;
  if (!webhookUrl || !bounty.paypalPayoutBatchId) return;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5_000);
  try {
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        event: "veripay.bounty.paid",
        bountyId: bounty.id,
        title: bounty.title,
        rewardUsd: Number(bounty.reward),
        freelancerPayPalEmail: bounty.freelancerEmail,
        aiScore: bounty.aiScore,
        paypalCaptureId: bounty.paypalCaptureId,
        paypalPayoutBatchId: bounty.paypalPayoutBatchId,
        status: "paid",
        completedAt: bounty.updatedAt.toISOString(),
      }),
      signal: controller.signal,
      cache: "no-store",
    });
    if (!response.ok) {
      console.error(`Zapier webhook returned HTTP ${response.status}.`);
    }
  } catch (error) {
    console.error("Could not deliver the VeriPay payout event to Zapier.", error);
  } finally {
    clearTimeout(timeout);
  }
}
