import { desc } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { bounties } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(bounties).orderBy(desc(bounties.createdAt));
    return NextResponse.json(rows, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Could not load bounties.", error);
    return NextResponse.json({ error: "Could not load bounties." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Enter valid bounty details." }, { status: 400 });
  }

  const title = typeof body.title === "string" ? body.title.trim() : "";
  const requirements = typeof body.requirements === "string" ? body.requirements.trim() : "";
  const freelancerEmail = typeof body.freelancerEmail === "string" ? body.freelancerEmail.trim() : "";
  const reward = Number(body.reward);
  const emailIsValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(freelancerEmail);

  if (!title || title.length > 180) {
    return NextResponse.json({ error: "Add a title with 1–180 characters." }, { status: 400 });
  }
  if (!requirements || requirements.length > 12_000) {
    return NextResponse.json({ error: "Add requirements with 1–12,000 characters." }, { status: 400 });
  }
  if (!Number.isFinite(reward) || reward < 1 || reward > 10_000) {
    return NextResponse.json({ error: "Reward must be between $1 and $10,000 USD." }, { status: 400 });
  }
  if (!emailIsValid || freelancerEmail.length > 254) {
    return NextResponse.json({ error: "Enter a valid freelancer PayPal email." }, { status: 400 });
  }

  try {
    const [bounty] = await db
      .insert(bounties)
      .values({
        title,
        requirements,
        reward: reward.toFixed(2),
        freelancerEmail,
        status: "draft",
      })
      .returning();

    return NextResponse.json(bounty, { status: 201, headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Could not create bounty.", error);
    return NextResponse.json({ error: "Could not create this bounty." }, { status: 500 });
  }
}
