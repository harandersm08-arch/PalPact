import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { bounties } from "@/db/schema";
import { capturePayPalOrder } from "@/lib/paypal";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: { bountyId?: unknown; orderId?: unknown };
  try {
    body = (await request.json()) as { bountyId?: unknown; orderId?: unknown };
  } catch {
    return NextResponse.json({ error: "Bounty and PayPal order IDs are required." }, { status: 400 });
  }

  const bountyId = typeof body.bountyId === "string" ? body.bountyId : "";
  const orderId = typeof body.orderId === "string" ? body.orderId : "";
  if (!bountyId || !orderId || orderId.length > 128) {
    return NextResponse.json({ error: "Bounty and PayPal order IDs are required." }, { status: 400 });
  }

  const [bounty] = await db.select().from(bounties).where(eq(bounties.id, bountyId)).limit(1);
  if (!bounty) return NextResponse.json({ error: "Bounty not found." }, { status: 404 });

  if (bounty.status === "in_escrow" && bounty.paypalOrderId === orderId) {
    return NextResponse.json({ bounty });
  }
  if (bounty.status !== "funding_pending" || bounty.paypalOrderId !== orderId) {
    return NextResponse.json({ error: "This PayPal order does not match an open bounty checkout." }, { status: 409 });
  }

  try {
    const capturedOrder = await capturePayPalOrder(orderId);
    const unit = capturedOrder.purchase_units?.find(
      (purchaseUnit) => purchaseUnit.custom_id === bounty.id || purchaseUnit.reference_id === bounty.id,
    );
    const capture = unit?.payments?.captures?.[0];
    const paidAmount = Number(capture?.amount?.value);
    const expectedAmount = Number(bounty.reward);

    if (
      capturedOrder.status !== "COMPLETED" ||
      capture?.status !== "COMPLETED" ||
      capture.amount?.currency_code !== "USD" ||
      !Number.isFinite(paidAmount) ||
      Math.abs(paidAmount - expectedAmount) > 0.001
    ) {
      return NextResponse.json({ error: "PayPal has not confirmed the full bounty payment." }, { status: 402 });
    }

    const [updated] = await db
      .update(bounties)
      .set({
        status: "in_escrow",
        paypalCaptureId: capture.id,
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(bounties.id, bounty.id),
          eq(bounties.status, "funding_pending"),
          eq(bounties.paypalOrderId, orderId),
        ),
      )
      .returning();

    if (!updated) {
      const [latest] = await db.select().from(bounties).where(eq(bounties.id, bounty.id)).limit(1);
      if (latest?.status === "in_escrow" && latest.paypalCaptureId === capture.id) {
        return NextResponse.json({ bounty: latest });
      }
      return NextResponse.json({ error: "The bounty changed while payment was being confirmed." }, { status: 409 });
    }

    return NextResponse.json({ bounty: updated });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not confirm PayPal payment.";
    console.error("PayPal order capture failed.", error);
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
