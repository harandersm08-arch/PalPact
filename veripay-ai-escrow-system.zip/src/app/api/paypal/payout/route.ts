import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { bounties } from "@/db/schema";
import { claimFailedPayout, executeClaimedPayout } from "@/lib/payout";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: { bountyId?: unknown };
  try {
    body = (await request.json()) as { bountyId?: unknown };
  } catch {
    return NextResponse.json({ error: "A bounty ID is required." }, { status: 400 });
  }

  const bountyId = typeof body.bountyId === "string" ? body.bountyId : "";
  if (!bountyId) return NextResponse.json({ error: "A bounty ID is required." }, { status: 400 });

  const [current] = await db.select().from(bounties).where(eq(bounties.id, bountyId)).limit(1);
  if (!current) return NextResponse.json({ error: "Bounty not found." }, { status: 404 });
  if (current.status !== "payout_failed" || (current.aiScore ?? 0) < 80) {
    return NextResponse.json({ error: "Only an AI-approved failed payout can be retried." }, { status: 409 });
  }

  const claimed = await claimFailedPayout(bountyId);
  if (!claimed) {
    return NextResponse.json({ error: "This payout is already being retried. Refresh the dashboard." }, { status: 409 });
  }

  try {
    const bounty = await executeClaimedPayout(claimed);
    return NextResponse.json({ bounty });
  } catch (error) {
    const message = error instanceof Error ? error.message : "PayPal payout failed.";
    const [bounty] = await db.select().from(bounties).where(eq(bounties.id, bountyId)).limit(1);
    console.error("PayPal payout retry failed.", error);
    return NextResponse.json({ error: message, bounty }, { status: 502 });
  }
}
