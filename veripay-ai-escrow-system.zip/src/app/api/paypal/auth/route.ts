import { NextResponse } from "next/server";
import { getPayPalAccessToken } from "@/lib/paypal";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const token = await getPayPalAccessToken();
    return NextResponse.json({ authenticated: true, expiresIn: token.expires_in });
  } catch (error) {
    const message = error instanceof Error ? error.message : "PayPal authentication failed.";
    console.error("PayPal OAuth authentication failed.", error);
    return NextResponse.json({ authenticated: false, error: message }, { status: 503 });
  }
}
