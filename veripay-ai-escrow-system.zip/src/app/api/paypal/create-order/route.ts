import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { bounties } from "@/db/schema";
import { createPayPalOrder } from "@/lib/paypal";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: { bountyId?: unknown };
  try {
    body = (await request.json()) as { bountyId?: unknown };
  } catch {
    return NextResponse.json({ error: "A bounty ID is required." }, { status: 400 });
  }

  const bountyId = typeof body.bountyId === "string" ? body.bountyId : "";
  if (!bountyId) return NextResponse.json({ error: "A bounty ID is required." }, { status: 400 });

  const [bounty] = await db.select().from(bounties).where(eq(bounties.id, bountyId)).limit(1);
  if (!bounty) return NextResponse.json({ error: "Bounty not found." }, { status: 404 });

  if (bounty.status === "funding_pending" && bounty.paypalOrderId) {
    return NextResponse.json({ orderId: bounty.paypalOrderId });
  }
  if (bounty.status !== "draft") {
    return NextResponse.json({ error: "Only an unfunded draft can be funded." }, { status: 409 });
  }

  try {
    const order = await createPayPalOrder(bounty);
    if (!order.id) throw new Error("PayPal did not return an order ID.");

    const [updated] = await db
      .update(bounties)
      .set({ status: "funding_pending", paypalOrderId: order.id, updatedAt: new Date() })
      .where(and(eq(bounties.id, bounty.id), eq(bounties.status, "draft")))
      .returning();

    if (!updated) {
      const [latest] = await db.select().from(bounties).where(eq(bounties.id, bounty.id)).limit(1);
      if (latest?.status === "funding_pending" && latest.paypalOrderId === order.id) {
        return NextResponse.json({ orderId: order.id });
      }
      return NextResponse.json({ error: "This bounty has already changed. Refresh and try again." }, { status: 409 });
    }

    return NextResponse.json({ orderId: order.id });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not start PayPal checkout.";
    console.error("PayPal order creation failed.", error);
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
