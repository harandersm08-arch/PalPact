"use client";

import { useMemo } from "react";
import {
  AllCommunityModule,
  ModuleRegistry,
  themeQuartz,
  type ColDef,
  type ICellRendererParams,
} from "ag-grid-community";
import { AgGridReact } from "ag-grid-react";
import { ArrowUpRight, Check, CircleDashed, RotateCcw, WalletCards } from "lucide-react";
import type { Bounty, DashboardView } from "@/lib/bounty-types";

ModuleRegistry.registerModules([AllCommunityModule]);

const gridTheme = themeQuartz.withParams({
  accentColor: "#315e4a",
  backgroundColor: "#ffffff",
  borderColor: "#eef0ec",
  foregroundColor: "#28362e",
  headerBackgroundColor: "#f8f9f6",
  fontFamily: "Inter, ui-sans-serif, system-ui, sans-serif",
  fontSize: 13,
});

const statusInfo: Record<Bounty["status"], { label: string; style: string; dot: string }> = {
  draft: { label: "Draft", style: "border-[#e7e9e5] bg-[#f6f7f5] text-[#6c756e]", dot: "bg-[#9aa29a]" },
  funding_pending: { label: "Awaiting funding", style: "border-[#eadab5] bg-[#fff8e9] text-[#8a6a24]", dot: "bg-[#c79a36]" },
  in_escrow: { label: "In escrow", style: "border-[#c9e1d1] bg-[#edf7f0] text-[#2c7047]", dot: "bg-[#4f9b69]" },
  revision_needed: { label: "Revision needed", style: "border-[#f0d5bc] bg-[#fff4ea] text-[#a75f28]", dot: "bg-[#db8952]" },
  payout_processing: { label: "Payout processing", style: "border-[#d9d4ee] bg-[#f4f1fc] text-[#6953a4]", dot: "bg-[#8b75c1]" },
  payout_failed: { label: "Payout failed", style: "border-[#f0caca] bg-[#fff0ef] text-[#ad4640]", dot: "bg-[#d36660]" },
  paid: { label: "Paid & completed", style: "border-[#c8e3db] bg-[#eaf6f2] text-[#28755e]", dot: "bg-[#49a384]" },
};

type BountyGridContext = {
  view: DashboardView;
  onAction: (bounty: Bounty) => void;
};

function TaskTitleCell({ data }: ICellRendererParams<Bounty>) {
  if (!data) return null;
  return (
    <div className="flex min-w-0 flex-col justify-center gap-1 py-2">
      <span className="truncate text-[13px] font-semibold tracking-[-0.01em] text-[#202e25]">{data.title}</span>
      <span className="truncate text-[11px] text-[#8a938c]">
        {data.id.slice(0, 8).toUpperCase()} <span className="px-1 text-[#c4c9c3]">·</span> {data.freelancerEmail}
      </span>
    </div>
  );
}

function StatusCell({ data }: ICellRendererParams<Bounty>) {
  if (!data) return null;
  const info = statusInfo[data.status];
  return (
    <span className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border px-2.5 py-1 text-[10px] font-semibold tracking-[0.01em] ${info.style}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${info.dot}`} />
      {info.label}
    </span>
  );
}

function ScoreCell({ data }: ICellRendererParams<Bounty>) {
  if (!data || data.aiScore === null) return <span className="text-sm text-[#a3aaa4]">—</span>;
  const passed = data.aiScore >= 80;
  return (
    <span className={`inline-flex items-baseline gap-1 font-semibold ${passed ? "text-[#2e7853]" : "text-[#b86638]"}`}>
      <span className="text-[15px]">{data.aiScore}</span>
      <span className="text-[10px] font-medium text-[#9aa19c]">/100</span>
    </span>
  );
}

function TransactionCell({ data }: ICellRendererParams<Bounty>) {
  if (!data) return null;
  const id = data.paypalPayoutBatchId || data.paypalCaptureId || data.paypalOrderId;
  const kind = data.paypalPayoutBatchId ? "PAYOUT BATCH" : data.paypalCaptureId ? "ESCROW CAPTURE" : "CHECKOUT ORDER";
  if (!id) return <span className="text-sm text-[#a3aaa4]">Not funded</span>;
  return (
    <div className="flex min-w-0 flex-col gap-1">
      <span className="text-[9px] font-semibold tracking-[0.13em] text-[#929a93]">{kind}</span>
      <span className="truncate font-mono text-[11px] text-[#4a574e]" title={id}>{id}</span>
    </div>
  );
}

function actionFor(bounty: Bounty, view: DashboardView) {
  if (view === "freelancer") {
    if (bounty.status === "in_escrow") return { label: "Submit work", type: "submit" as const };
    if (bounty.status === "revision_needed") return { label: "Submit revision", type: "submit" as const };
    if (bounty.status === "paid") return { label: "View receipt", type: "receipt" as const };
    if (bounty.status === "payout_processing") return { label: "Processing…", type: "disabled" as const };
    return { label: "Waiting for client", type: "disabled" as const };
  }

  if (bounty.status === "draft") return { label: "Fund bounty", type: "fund" as const };
  if (bounty.status === "funding_pending") return { label: "Resume checkout", type: "fund" as const };
  if (bounty.status === "in_escrow" || bounty.status === "revision_needed") return { label: "View brief", type: "brief" as const };
  if (bounty.status === "payout_processing") return { label: "Processing…", type: "disabled" as const };
  if (bounty.status === "payout_failed") return { label: "Retry payout", type: "retry" as const };
  return { label: "View receipt", type: "receipt" as const };
}

function ActionCell({ data, context }: ICellRendererParams<Bounty, unknown, BountyGridContext>) {
  if (!data || !context) return null;
  const action = actionFor(data, context.view);
  const Icon = action.type === "submit" ? ArrowUpRight : action.type === "retry" ? RotateCcw : action.type === "receipt" ? WalletCards : action.type === "disabled" ? CircleDashed : Check;
  return (
    <button
      type="button"
      onClick={(event) => {
        event.stopPropagation();
        if (action.type !== "disabled") context.onAction(data);
      }}
      disabled={action.type === "disabled"}
      className={`inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-[11px] font-semibold transition ${
        action.type === "disabled"
          ? "cursor-default text-[#a3aaa4]"
          : action.type === "submit"
            ? "bg-[#18392a] text-white shadow-sm hover:bg-[#24513a]"
            : "border border-[#e4e8e2] bg-white text-[#385140] hover:border-[#b9cbbb] hover:bg-[#f6faf6]"
      }`}
    >
      <Icon size={13} strokeWidth={2.2} />
      {action.label}
    </button>
  );
}

export default function BountyGrid({
  rows,
  view,
  onAction,
}: {
  rows: Bounty[];
  view: DashboardView;
  onAction: (bounty: Bounty) => void;
}) {
  const columnDefs = useMemo<ColDef<Bounty>[]>(
    () => [
      { field: "title", headerName: "Task title", minWidth: 255, flex: 2.15, cellRenderer: TaskTitleCell },
      {
        field: "reward",
        headerName: "Reward",
        minWidth: 112,
        flex: 0.7,
        cellClass: "font-semibold text-[#293a30]",
        valueFormatter: (params) =>
          new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(Number(params.value || 0)),
      },
      { field: "status", headerName: "Status", minWidth: 160, flex: 1.05, cellRenderer: StatusCell },
      { field: "aiScore", headerName: "AI score", minWidth: 105, flex: 0.62, cellRenderer: ScoreCell },
      {
        colId: "paypalReference",
        headerName: "PayPal transaction / payout ID",
        minWidth: 215,
        flex: 1.6,
        cellRenderer: TransactionCell,
      },
      {
        colId: "action",
        headerName: "Action",
        minWidth: 158,
        width: 168,
        maxWidth: 184,
        sortable: false,
        cellRenderer: ActionCell,
      },
    ],
    [],
  );

  return (
    <div className="veripay-grid h-[430px] w-full">
      <AgGridReact<Bounty>
        theme={gridTheme}
        rowData={rows}
        columnDefs={columnDefs}
        defaultColDef={{ sortable: true, resizable: true, filter: false, suppressMovable: true }}
        context={{ view, onAction }}
        rowHeight={72}
        headerHeight={46}
        getRowId={(params) => params.data.id}
        suppressCellFocus
        suppressNoRowsOverlay
        animateRows
      />
    </div>
  );
}
