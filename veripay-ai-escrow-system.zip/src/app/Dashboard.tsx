"use client";

import dynamic from "next/dynamic";
import {
  PayPalButtons,
  PayPalScriptProvider,
} from "@paypal/react-paypal-js";
import {
  Activity,
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  Banknote,
  Bell,
  BookOpenCheck,
  BriefcaseBusiness,
  Check,
  CheckCircle2,
  ChevronDown,
  CircleDollarSign,
  CircleHelp,
  ClipboardCheck,
  Copy,
  CreditCard,
  FileText,
  LayoutDashboard,
  LoaderCircle,
  LockKeyhole,
  Menu,
  Plus,
  Search,
  ShieldCheck,
  Sparkles,
  WalletCards,
  X,
} from "lucide-react";
import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import type { Bounty, BountyStatus, DashboardView } from "@/lib/bounty-types";

const BountyGrid = dynamic(() => import("./BountyGrid"), {
  ssr: false,
  loading: () => <div className="h-[430px] animate-pulse rounded-b-[18px] bg-[#fbfcfa]" />,
});

type NewBountyForm = {
  title: string;
  requirements: string;
  reward: string;
  freelancerEmail: string;
};

type ReviewResult = {
  passed: boolean;
  bounty: Bounty;
  error?: string;
};

type Notice = { kind: "success" | "error"; message: string };

const emptyForm: NewBountyForm = { title: "", requirements: "", reward: "75", freelancerEmail: "" };

const statusPresentation: Record<BountyStatus, { title: string; dot: string; text: string; surface: string }> = {
  draft: { title: "Draft", dot: "bg-[#919a91]", text: "text-[#667168]", surface: "bg-[#f4f6f3]" },
  funding_pending: { title: "Awaiting funding", dot: "bg-[#cb9b3b]", text: "text-[#886626]", surface: "bg-[#fff8e9]" },
  in_escrow: { title: "In escrow", dot: "bg-[#4d9a66]", text: "text-[#327248]", surface: "bg-[#edf7ef]" },
  revision_needed: { title: "Revision needed", dot: "bg-[#d88a50]", text: "text-[#a35b2b]", surface: "bg-[#fff4e9]" },
  payout_processing: { title: "Payout processing", dot: "bg-[#8871be]", text: "text-[#66529c]", surface: "bg-[#f3f0fb]" },
  payout_failed: { title: "Payout failed", dot: "bg-[#d0625d]", text: "text-[#a74741]", surface: "bg-[#fff0ef]" },
  paid: { title: "Paid & completed", dot: "bg-[#49a384]", text: "text-[#28745d]", surface: "bg-[#eaf6f2]" },
};

async function requestJson<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, { ...init, cache: "no-store" });
  const payload = (await response.json().catch(() => ({}))) as { error?: string } & T;
  if (!response.ok) throw new Error(payload.error || "Something went wrong. Please try again.");
  return payload as T;
}

function formatCurrency(value: string | number) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(Number(value) || 0);
}

function StatusBadge({ status }: { status: BountyStatus }) {
  const item = statusPresentation[status];
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-semibold ${item.surface} ${item.text}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${item.dot}`} />
      {item.title}
    </span>
  );
}

function Modal({
  title,
  subtitle,
  onClose,
  children,
  size = "max-w-xl",
}: {
  title: string;
  subtitle?: string;
  onClose: () => void;
  children: ReactNode;
  size?: string;
}) {
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#0d1d14]/55 p-3 backdrop-blur-[3px] sm:p-6"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <section
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={`modal-scroll max-h-[min(92vh,900px)] w-full ${size} overflow-y-auto rounded-[22px] border border-white/70 bg-white shadow-[0_28px_90px_rgba(13,29,20,0.26)]`}
      >
        <header className="sticky top-0 z-10 flex items-start justify-between gap-4 border-b border-[#edf0eb] bg-white/95 px-5 py-4 backdrop-blur sm:px-7 sm:py-5">
          <div>
            <h2 className="text-[18px] font-semibold tracking-[-0.03em] text-[#1d3024]">{title}</h2>
            {subtitle && <p className="mt-1 text-[12px] leading-5 text-[#7e8980]">{subtitle}</p>}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close dialog"
            className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-[#707b71] transition hover:bg-[#f0f3ef] hover:text-[#243a2b]"
          >
            <X size={17} />
          </button>
        </header>
        {children}
      </section>
    </div>
  );
}

function StatCard({
  label,
  value,
  caption,
  icon,
  tint,
}: {
  label: string;
  value: string;
  caption: string;
  icon: ReactNode;
  tint: "mint" | "sand" | "lavender";
}) {
  const tintClass = {
    mint: "bg-[#e9f4ec] text-[#3c8055]",
    sand: "bg-[#fbf2df] text-[#a67b28]",
    lavender: "bg-[#efecf9] text-[#7763ad]",
  }[tint];
  return (
    <article className="rounded-[18px] border border-[#e9ece7] bg-white p-4 shadow-[0_2px_10px_rgba(25,40,30,0.025)] sm:p-5">
      <div className="flex items-center justify-between gap-3">
        <p className="text-[11px] font-semibold uppercase tracking-[0.09em] text-[#879188]">{label}</p>
        <span className={`grid h-9 w-9 place-items-center rounded-xl ${tintClass}`}>{icon}</span>
      </div>
      <div className="mt-3 flex items-end justify-between gap-3">
        <strong className="text-[26px] font-semibold leading-none tracking-[-0.045em] text-[#203329]">{value}</strong>
        <span className="mb-0.5 text-right text-[10px] leading-4 text-[#929b93]">{caption}</span>
      </div>
    </article>
  );
}

function FieldLabel({ children }: { children: ReactNode }) {
  return <span className="mb-1.5 block text-[11px] font-semibold text-[#445248]">{children}</span>;
}

function DashboardWorkspace({ paypalClientReady }: { paypalClientReady: boolean }) {
  const [bounties, setBounties] = useState<Bounty[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [view, setView] = useState<DashboardView>("client");
  const [search, setSearch] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [createStage, setCreateStage] = useState<"details" | "checkout">("details");
  const [form, setForm] = useState<NewBountyForm>(emptyForm);
  const [creating, setCreating] = useState(false);
  const [fundingBounty, setFundingBounty] = useState<Bounty | null>(null);
  const [fundingError, setFundingError] = useState("");
  const [fundingBusy, setFundingBusy] = useState(false);
  const [submissionBounty, setSubmissionBounty] = useState<Bounty | null>(null);
  const [submissionText, setSubmissionText] = useState("");
  const [reviewing, setReviewing] = useState(false);
  const [reviewResult, setReviewResult] = useState<ReviewResult | null>(null);
  const [receiptBounty, setReceiptBounty] = useState<Bounty | null>(null);
  const [briefBounty, setBriefBounty] = useState<Bounty | null>(null);
  const [retryingId, setRetryingId] = useState<string | null>(null);
  const [notice, setNotice] = useState<Notice | null>(null);
  const [paypalConnected, setPaypalConnected] = useState(false);
  const [paypalChecking, setPaypalChecking] = useState(paypalClientReady);

  const upsertBounty = useCallback((bounty: Bounty) => {
    setBounties((current) => {
      const exists = current.some((item) => item.id === bounty.id);
      return exists
        ? current.map((item) => (item.id === bounty.id ? bounty : item))
        : [bounty, ...current];
    });
  }, []);

  const fetchBounties = useCallback(() => requestJson<Bounty[]>("/api/bounties"), []);

  const loadBounties = useCallback(async () => {
    try {
      const rows = await fetchBounties();
      setBounties(rows);
      setLoadError("");
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : "Could not load bounties.");
    } finally {
      setLoading(false);
    }
  }, [fetchBounties]);

  useEffect(() => {
    let cancelled = false;
    void fetchBounties()
      .then((rows) => {
        if (!cancelled) {
          setBounties(rows);
          setLoadError("");
        }
      })
      .catch((error: unknown) => {
        if (!cancelled) setLoadError(error instanceof Error ? error.message : "Could not load bounties.");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [fetchBounties]);

  useEffect(() => {
    if (!notice) return;
    const timeout = window.setTimeout(() => setNotice(null), 4200);
    return () => window.clearTimeout(timeout);
  }, [notice]);

  useEffect(() => {
    if (!paypalClientReady) return;
    let cancelled = false;
    void fetch("/api/paypal/auth", { cache: "no-store" })
      .then(async (response) => {
        const payload = (await response.json().catch(() => ({}))) as { authenticated?: boolean };
        if (!cancelled) setPaypalConnected(response.ok && payload.authenticated === true);
      })
      .catch(() => {
        if (!cancelled) setPaypalConnected(false);
      })
      .finally(() => {
        if (!cancelled) setPaypalChecking(false);
      });
    return () => {
      cancelled = true;
    };
  }, [paypalClientReady]);

  const visibleBounties = useMemo(() => {
    const query = search.trim().toLowerCase();
    return bounties.filter((bounty) => {
      if (view === "freelancer" && !["in_escrow", "revision_needed", "payout_processing", "paid", "payout_failed"].includes(bounty.status)) {
        return false;
      }
      if (!query) return true;
      return [bounty.title, bounty.freelancerEmail, bounty.id, bounty.status]
        .some((value) => value.toLowerCase().includes(query));
    });
  }, [bounties, search, view]);

  const activeCount = bounties.filter((item) => ["in_escrow", "revision_needed"].includes(item.status)).length;
  const escrowTotal = bounties
    .filter((item) => ["in_escrow", "revision_needed", "payout_processing"].includes(item.status))
    .reduce((total, item) => total + Number(item.reward), 0);
  const paidTotal = bounties
    .filter((item) => item.status === "paid")
    .reduce((total, item) => total + Number(item.reward), 0);

  const openCreate = () => {
    setForm(emptyForm);
    setFundingBounty(null);
    setFundingError("");
    setCreateStage("details");
    setCreateOpen(true);
  };

  const closeFunding = () => {
    setCreateOpen(false);
    setFundingBounty(null);
    setFundingError("");
    setFundingBusy(false);
  };

  const createBounty = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setCreating(true);
    setFundingError("");
    try {
      const bounty = await requestJson<Bounty>("/api/bounties", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      upsertBounty(bounty);
      setFundingBounty(bounty);
      setCreateStage("checkout");
      setNotice({ kind: "success", message: "Bounty drafted. Complete sandbox checkout to publish it." });
    } catch (error) {
      setFundingError(error instanceof Error ? error.message : "Could not create the bounty.");
    } finally {
      setCreating(false);
    }
  };

  const handleGridAction = useCallback((bounty: Bounty) => {
    if (view === "freelancer" && ["in_escrow", "revision_needed"].includes(bounty.status)) {
      setSubmissionBounty(bounty);
      setSubmissionText(bounty.submission ?? "");
      setReviewResult(null);
      return;
    }
    if (bounty.status === "draft" || bounty.status === "funding_pending") {
      setFundingBounty(bounty);
      setFundingError("");
      setCreateStage("checkout");
      setCreateOpen(true);
      return;
    }
    if (bounty.status === "payout_failed") {
      setBriefBounty(bounty);
      return;
    }
    if (bounty.status === "paid") {
      setReceiptBounty(bounty);
      return;
    }
    setBriefBounty(bounty);
  }, [view]);

  const createCheckoutOrder = async () => {
    if (!fundingBounty) throw new Error("Choose a bounty to fund first.");
    setFundingBusy(true);
    setFundingError("");
    try {
      const response = await requestJson<{ orderId: string }>("/api/paypal/create-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bountyId: fundingBounty.id }),
      });
      const updated = { ...fundingBounty, status: "funding_pending" as const, paypalOrderId: response.orderId };
      upsertBounty(updated);
      setFundingBounty(updated);
      return response.orderId;
    } catch (error) {
      setFundingBusy(false);
      const message = error instanceof Error ? error.message : "Could not start checkout.";
      setFundingError(message);
      throw error;
    }
  };

  const captureCheckoutOrder = async (orderId?: string) => {
    if (!fundingBounty || !orderId) {
      setFundingError("PayPal did not return an order ID. Please try checkout again.");
      setFundingBusy(false);
      return;
    }
    setFundingBusy(true);
    setFundingError("");
    try {
      const response = await requestJson<{ bounty: Bounty }>("/api/paypal/capture-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bountyId: fundingBounty.id, orderId }),
      });
      upsertBounty(response.bounty);
      closeFunding();
      setNotice({ kind: "success", message: `${response.bounty.title} is live in escrow.` });
    } catch (error) {
      setFundingError(error instanceof Error ? error.message : "Could not confirm the PayPal payment.");
      setFundingBusy(false);
    }
  };

  const reviewSubmission = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!submissionBounty || !submissionText.trim()) return;
    setReviewing(true);
    setReviewResult(null);
    try {
      const response = await fetch("/api/verify-and-payout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bountyId: submissionBounty.id, submission: submissionText.trim() }),
        cache: "no-store",
      });
      const payload = (await response.json().catch(() => ({}))) as {
        error?: string;
        passed?: boolean;
        bounty?: Bounty;
      };
      if (payload.bounty) {
        upsertBounty(payload.bounty);
        setSubmissionBounty(payload.bounty);
      }
      if (!response.ok && !payload.bounty) {
        throw new Error(payload.error || "The AI review could not be completed.");
      }
      if (payload.bounty) {
        setReviewResult({
          passed: payload.passed === true,
          bounty: payload.bounty,
          error: response.ok ? undefined : payload.error,
        });
      }
    } catch (error) {
      setNotice({ kind: "error", message: error instanceof Error ? error.message : "The AI review failed." });
    } finally {
      setReviewing(false);
    }
  };

  const retryPayout = async (bounty: Bounty) => {
    setRetryingId(bounty.id);
    try {
      const response = await requestJson<{ bounty: Bounty }>("/api/paypal/payout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bountyId: bounty.id }),
      });
      upsertBounty(response.bounty);
      setBriefBounty(null);
      setNotice({ kind: "success", message: "Payout accepted by PayPal. Batch receipt is ready." });
    } catch (error) {
      await loadBounties();
      setNotice({ kind: "error", message: error instanceof Error ? error.message : "Payout retry failed." });
    } finally {
      setRetryingId(null);
    }
  };

  const copyText = async (value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setNotice({ kind: "success", message: "Copied to clipboard." });
    } catch {
      setNotice({ kind: "error", message: "Clipboard access is unavailable in this browser." });
    }
  };

  const closeSubmission = () => {
    setSubmissionBounty(null);
    setReviewResult(null);
    setReviewing(false);
  };

  const nav = (
    <>
      <div className="flex items-center gap-3 px-5 pb-8 pt-6">
        <div className="grid h-10 w-10 place-items-center rounded-[13px] bg-[#b7d69f] text-[#183b2a] shadow-[0_5px_18px_rgba(147,194,131,0.15)]">
          <ShieldCheck size={22} strokeWidth={2.3} />
        </div>
        <div>
          <div className="text-[17px] font-semibold tracking-[-0.04em] text-white">veripay<span className="text-[#b5d59e]">.</span></div>
          <div className="mt-0.5 text-[9px] font-semibold uppercase tracking-[0.15em] text-[#8ca294]">Work, verified.</div>
        </div>
      </div>
      <div className="px-4">
        <p className="mb-2 px-3 text-[9px] font-bold uppercase tracking-[0.16em] text-[#728777]">Workspace</p>
        <button
          type="button"
          onClick={() => document.getElementById("bounties")?.scrollIntoView({ behavior: "smooth" })}
          className="flex w-full items-center gap-3 rounded-xl bg-[#294a36] px-3 py-2.5 text-left text-[12px] font-semibold text-white shadow-[inset_0_0_0_1px_rgba(255,255,255,.04)]"
        >
          <LayoutDashboard size={16} className="text-[#b5d59e]" /> Overview
          <span className="ml-auto rounded-full bg-[#416149] px-2 py-0.5 text-[9px] text-[#d8e8da]">Live</span>
        </button>
        <button
          type="button"
          onClick={() => document.getElementById("bounties")?.scrollIntoView({ behavior: "smooth" })}
          className="mt-1.5 flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-[12px] font-medium text-[#aebdb1] transition hover:bg-white/[0.06] hover:text-white"
        >
          <BriefcaseBusiness size={16} /> Bounties
        </button>
        <button
          type="button"
          onClick={() => setView("client")}
          className="mt-1.5 flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-[12px] font-medium text-[#aebdb1] transition hover:bg-white/[0.06] hover:text-white"
        >
          <WalletCards size={16} /> Escrow & payouts
        </button>
      </div>
      <div className="mt-auto px-4 pb-5">
        <div className="rounded-[15px] border border-white/[0.08] bg-white/[0.035] p-3.5">
          <div className="flex items-center gap-2 text-[11px] font-semibold text-[#dfeae1]">
            <span className={`h-2 w-2 rounded-full ${paypalConnected ? "bg-[#85c88d]" : "bg-[#c9a85f]"}`} />
            Sandbox workspace
          </div>
          <p className="mt-2 text-[10px] leading-[1.55] text-[#93a498]">Payments use PayPal Sandbox. No real money moves here.</p>
          <div className="mt-3 flex items-center gap-1.5 text-[9px] font-medium text-[#6f8775]">
            <LockKeyhole size={11} /> Secure escrow flow
          </div>
        </div>
        <div className="mt-4 flex items-center gap-2.5 px-1">
          <div className="grid h-8 w-8 place-items-center rounded-full bg-[#dce9db] text-[10px] font-bold text-[#244832]">MM</div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-[11px] font-semibold text-[#e9f1eb]">Maya Morgan</p>
            <p className="mt-0.5 text-[9px] text-[#809385]">Workspace owner</p>
          </div>
          <ChevronDown size={14} className="text-[#718476]" />
        </div>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-[#f4f5f2] text-[#25342b]">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[226px] flex-col bg-[#12281c] lg:flex">{nav}</aside>
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-[#0d1d14]/45 lg:hidden" onClick={() => setMobileMenuOpen(false)}>
          <aside className="flex h-full w-[255px] flex-col bg-[#12281c] shadow-2xl" onClick={(event) => event.stopPropagation()}>
            <button type="button" onClick={() => setMobileMenuOpen(false)} className="absolute left-[217px] top-5 rounded-full bg-white/10 p-2 text-white" aria-label="Close menu"><X size={16} /></button>
            {nav}
          </aside>
        </div>
      )}

      <div className="min-h-screen lg:pl-[226px]">
        <header className="sticky top-0 z-20 flex h-[62px] items-center justify-between border-b border-[#e7eae5] bg-[#f8f9f6]/90 px-4 backdrop-blur-md sm:px-7 lg:px-9">
          <div className="flex items-center gap-3">
            <button type="button" onClick={() => setMobileMenuOpen(true)} className="grid h-8 w-8 place-items-center rounded-lg border border-[#e4e8e2] bg-white text-[#607064] lg:hidden" aria-label="Open navigation"><Menu size={17} /></button>
            <div className="flex items-center gap-2 text-[11px] text-[#859087]">
              <span className="font-semibold text-[#38473c]">Workspace</span><span className="text-[#c1c8c0]">/</span><span>Overview</span>
            </div>
          </div>
          <div className="flex items-center gap-2.5 sm:gap-4">
            <div className={`hidden items-center gap-1.5 rounded-full border px-2.5 py-1.5 text-[10px] font-semibold sm:flex ${paypalConnected ? "border-[#cfe2d2] bg-[#f0f8f0] text-[#39764a]" : "border-[#e4e7e2] bg-white text-[#7f887f]"}`}>
              <span className={`h-1.5 w-1.5 rounded-full ${paypalConnected ? "bg-[#58a16c]" : paypalChecking ? "animate-pulse bg-[#c39d51]" : "bg-[#b7beb6]"}`} />
              {paypalConnected ? "PayPal sandbox connected" : paypalChecking ? "Checking PayPal…" : paypalClientReady ? "PayPal setup needed" : "Sandbox mode"}
            </div>
            <button type="button" onClick={() => setNotice({ kind: "success", message: "You’re all caught up." })} aria-label="Notifications" className="relative grid h-8 w-8 place-items-center rounded-full text-[#7a857c] transition hover:bg-white hover:text-[#2c4734]">
              <Bell size={16} />
              {bounties.some((item) => item.status === "revision_needed" || item.status === "payout_failed") && <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-[#d9785e] ring-2 ring-[#f8f9f6]" />}
            </button>
            <div className="grid h-8 w-8 place-items-center rounded-full bg-[#dce9db] text-[10px] font-bold text-[#244832]">MM</div>
          </div>
        </header>

        <main className="mx-auto max-w-[1500px] px-4 pb-12 pt-6 sm:px-7 sm:pt-8 lg:px-9">
          <section className="relative overflow-hidden rounded-[23px] bg-[#173a29] px-5 py-6 text-white shadow-[0_9px_25px_rgba(28,61,42,0.12)] sm:px-8 sm:py-8">
            <div className="hero-grain pointer-events-none absolute inset-0 opacity-30" />
            <div className="absolute -right-16 -top-32 h-[310px] w-[310px] rounded-full border border-white/[0.08]" />
            <div className="absolute -right-3 -top-[78px] h-[225px] w-[225px] rounded-full border border-white/[0.08]" />
            <div className="absolute right-[10%] top-[17%] hidden h-[160px] w-[160px] rounded-full bg-[#9bc887]/[0.08] blur-3xl md:block" />
            <div className="relative z-10 flex flex-col justify-between gap-6 md:min-h-[155px] md:flex-row md:items-end">
              <div className="max-w-[620px]">
                <span className="inline-flex items-center gap-1.5 rounded-full border border-[#aac993]/25 bg-[#a6cc91]/10 px-2.5 py-1 text-[9px] font-bold uppercase tracking-[0.13em] text-[#c7e2b7]">
                  <Sparkles size={11} /> Autonomous freelance escrow
                </span>
                <h1 className="mt-4 max-w-[520px] text-[30px] font-semibold leading-[1.06] tracking-[-0.055em] sm:text-[37px]">Great work. Verified.<br className="hidden sm:block" /> Paid without the wait.</h1>
                <p className="mt-3 max-w-[500px] text-[12px] leading-5 text-[#c0d0c3] sm:text-[13px]">Fund a bounty, let AI review the delivery, and send a PayPal payout the moment it passes.</p>
              </div>
              <div className="hidden min-w-[210px] rounded-[16px] border border-white/[0.12] bg-[#f7fbf4]/[0.06] p-4 backdrop-blur-sm md:block">
                <div className="flex items-center gap-2 text-[9px] font-bold uppercase tracking-[0.13em] text-[#a9c2ad]"><ShieldCheck size={13} /> Protected by escrow</div>
                <div className="mt-3 flex items-end justify-between">
                  <div><p className="text-[10px] text-[#a5baaa]">AI approval threshold</p><p className="mt-1 text-[24px] font-semibold leading-none tracking-[-0.045em] text-white">80<span className="ml-1 text-[12px] font-medium text-[#a8c6a7]">/100</span></p></div>
                  <div className="grid h-9 w-9 place-items-center rounded-xl bg-[#8ab779]/20 text-[#c0dea9]"><CheckCircle2 size={19} /></div>
                </div>
              </div>
            </div>
          </section>

          <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
            <StatCard label="Active in escrow" value={String(activeCount).padStart(2, "0")} caption="Tasks waiting on delivery" icon={<BookOpenCheck size={17} />} tint="mint" />
            <StatCard label="Value in escrow" value={formatCurrency(escrowTotal)} caption="Protected until approval" icon={<LockKeyhole size={17} />} tint="sand" />
            <StatCard label="Paid to freelancers" value={formatCurrency(paidTotal)} caption={`${bounties.filter((item) => item.status === "paid").length} completed ${bounties.filter((item) => item.status === "paid").length === 1 ? "bounty" : "bounties"}`} icon={<Banknote size={17} />} tint="lavender" />
          </div>

          <section id="bounties" className="mt-7 scroll-mt-24">
            <div className="mb-4 flex flex-col justify-between gap-4 md:flex-row md:items-end">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-[19px] font-semibold tracking-[-0.04em] text-[#25372b]">Bounty workspace</h2>
                  <span className="rounded-full bg-[#e9eee8] px-2 py-0.5 text-[9px] font-bold text-[#69766b]">{visibleBounties.length}</span>
                </div>
                <p className="mt-1 text-[11px] text-[#879188]">Track funded tasks, reviews, and PayPal transactions in one place.</p>
              </div>
              <div className="flex flex-wrap items-center gap-2.5">
                <div className="flex items-center rounded-[10px] border border-[#e4e8e2] bg-white p-1 shadow-[0_2px_5px_rgba(25,40,30,.025)]">
                  <button type="button" onClick={() => setView("client")} className={`rounded-[7px] px-3 py-1.5 text-[10px] font-semibold transition ${view === "client" ? "bg-[#173a29] text-white shadow-sm" : "text-[#748077] hover:text-[#2e4937]"}`}>Client view</button>
                  <button type="button" onClick={() => setView("freelancer")} className={`rounded-[7px] px-3 py-1.5 text-[10px] font-semibold transition ${view === "freelancer" ? "bg-[#173a29] text-white shadow-sm" : "text-[#748077] hover:text-[#2e4937]"}`}>Freelancer view</button>
                </div>
                {view === "client" && (
                  <button type="button" onClick={openCreate} className="inline-flex h-[36px] items-center gap-1.5 rounded-[10px] bg-[#b8d89f] px-3.5 text-[11px] font-bold text-[#183b29] shadow-[0_2px_5px_rgba(33,70,45,.08)] transition hover:bg-[#c6e2b0]">
                    <Plus size={14} strokeWidth={2.5} /> Create bounty
                  </button>
                )}
              </div>
            </div>

            <div className="overflow-hidden rounded-[18px] border border-[#e7ebe5] bg-white shadow-[0_5px_20px_rgba(35,50,38,0.035)]">
              <div className="flex flex-col justify-between gap-3 border-b border-[#edf0ec] px-4 py-3.5 sm:flex-row sm:items-center sm:px-5">
                <div className="flex items-center gap-2.5">
                  <span className="grid h-8 w-8 place-items-center rounded-[10px] bg-[#eff5ed] text-[#4c7653]"><ClipboardCheck size={16} /></span>
                  <div>
                    <p className="text-[12px] font-semibold text-[#304136]">{view === "client" ? "All bounties" : "Available work & earnings"}</p>
                    <p className="mt-0.5 text-[9px] text-[#929a93]">Updated just now <span className="mx-1 text-[#c9cec8]">·</span> live workspace</p>
                  </div>
                </div>
                <div className="flex items-center gap-2.5">
                  <label className="relative block w-full sm:w-[220px]">
                    <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9ca59d]" />
                    <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search tasks..." className="h-[34px] w-full rounded-[9px] border border-[#e8ebe6] bg-[#fcfdfb] pl-9 pr-3 text-[10px] text-[#3b4a40] outline-none transition placeholder:text-[#a3aaa4] focus:border-[#a7c4ab] focus:bg-white" />
                  </label>
                  <button type="button" onClick={() => void loadBounties()} aria-label="Refresh bounties" className="grid h-[34px] w-[34px] shrink-0 place-items-center rounded-[9px] border border-[#e8ebe6] bg-white text-[#738077] transition hover:bg-[#f5f8f4] hover:text-[#3a6043]"><Activity size={14} /></button>
                </div>
              </div>
              {loadError && (
                <div className="flex flex-col items-start justify-between gap-2 border-b border-[#f0d8d5] bg-[#fff6f5] px-5 py-3 text-[11px] text-[#9a5049] sm:flex-row sm:items-center">
                  <span>{loadError}</span><button type="button" onClick={() => void loadBounties()} className="font-semibold underline underline-offset-2">Try again</button>
                </div>
              )}
              {loading ? (
                <div className="flex h-[430px] items-center justify-center gap-2 text-[12px] text-[#849087]"><LoaderCircle size={16} className="animate-spin" /> Loading bounties…</div>
              ) : (
                <BountyGrid rows={visibleBounties} view={view} onAction={handleGridAction} />
              )}
              {!loading && !loadError && bounties.length === 0 && (
                <div className="-mt-[230px] pointer-events-none relative z-10 mx-auto flex w-fit flex-col items-center text-center">
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-[#f0f5ee] text-[#5d865f]"><BriefcaseBusiness size={19} /></span>
                  <p className="mt-3 text-[12px] font-semibold text-[#38473c]">A little room for great work.</p>
                  <p className="mt-1 text-[10px] text-[#89938a]">{view === "client" ? "Create your first bounty to get the ball rolling." : "Funded tasks will show up here when they are ready."}</p>
                  {view === "client" && <span className="pointer-events-auto mt-3"><button type="button" onClick={openCreate} className="inline-flex items-center gap-1 text-[10px] font-bold text-[#3e7750] hover:text-[#255b38]"><Plus size={12} /> Create a bounty</button></span>}
                </div>
              )}
              {!loading && bounties.length > 0 && visibleBounties.length === 0 && (
                <div className="pointer-events-none relative z-10 -mt-[230px] flex flex-col items-center text-center">
                  <Search size={21} className="text-[#a0aaa0]" />
                  <p className="mt-2 text-[11px] font-semibold text-[#506052]">No matching bounties</p>
                  <p className="mt-1 text-[10px] text-[#929b93]">Try another search or switch workspace view.</p>
                </div>
              )}
            </div>
            <div className="mt-3 flex flex-col justify-between gap-2 px-1 text-[9px] text-[#929b94] sm:flex-row sm:items-center">
              <span className="flex items-center gap-1.5"><ShieldCheck size={12} className="text-[#5b8b62]" /> Client funds are captured before a task enters escrow.</span>
              <span>AI review is advisory and configured with your OpenAI API key.</span>
            </div>
          </section>

          <footer className="mt-9 flex flex-col justify-between gap-2 border-t border-[#e5e9e3] pt-4 text-[9px] text-[#a0a8a1] sm:flex-row">
            <span>© 2025 VeriPay AI <span className="mx-1.5 text-[#c8cec8]">·</span> Built for work that ships.</span>
            <span className="flex items-center gap-1.5"><ShieldCheck size={11} /> Sandbox environment · No real payouts</span>
          </footer>
        </main>
      </div>

      {createOpen && (
        <Modal
          title={createStage === "details" ? "Create a new bounty" : "Fund your bounty"}
          subtitle={createStage === "details" ? "Write a clear brief. Funds stay in PayPal escrow until the work passes review." : "Your bounty is ready. Complete sandbox checkout to publish it to freelancers."}
          onClose={closeFunding}
          size="max-w-[560px]"
        >
          <div className="px-5 pb-6 pt-5 sm:px-7">
            <div className="mb-5 flex items-center gap-2">
              <span className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[9px] font-bold ${createStage === "details" ? "bg-[#eaf3e8] text-[#42764b]" : "bg-[#f1f4f0] text-[#8c968d]"}`}><span className="grid h-4 w-4 place-items-center rounded-full bg-white text-[8px]">01</span> Details</span>
              <span className="h-px w-6 bg-[#e3e8e1]" />
              <span className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[9px] font-bold ${createStage === "checkout" ? "bg-[#eaf3e8] text-[#42764b]" : "bg-[#f1f4f0] text-[#8c968d]"}`}><span className="grid h-4 w-4 place-items-center rounded-full bg-white text-[8px]">02</span> Fund</span>
            </div>

            {createStage === "details" ? (
              <form onSubmit={createBounty} className="space-y-4">
                <label className="block"><FieldLabel>Task title</FieldLabel><input required maxLength={180} value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} placeholder="e.g. Build a landing page hero" className="form-field h-10" /></label>
                <label className="block"><FieldLabel>Detailed requirements</FieldLabel><textarea required maxLength={12000} rows={4} value={form.requirements} onChange={(event) => setForm({ ...form, requirements: event.target.value })} placeholder="Describe the deliverable, must-have details, and what a successful handoff looks like…" className="form-field min-h-[104px] resize-y py-2.5 leading-5" /></label>
                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="block"><FieldLabel>Reward (USD)</FieldLabel><div className="relative"><span className="absolute left-3 top-1/2 -translate-y-1/2 text-[12px] font-semibold text-[#68766c]">$</span><input required type="number" min="1" max="10000" step="0.01" value={form.reward} onChange={(event) => setForm({ ...form, reward: event.target.value })} className="form-field h-10 pl-7" /></div></label>
                  <label className="block"><FieldLabel>Freelancer PayPal email</FieldLabel><input required type="email" maxLength={254} value={form.freelancerEmail} onChange={(event) => setForm({ ...form, freelancerEmail: event.target.value })} placeholder="freelancer@example.com" className="form-field h-10" /></label>
                </div>
                <div className="flex items-start gap-2.5 rounded-xl border border-[#e7eee4] bg-[#f5f9f3] px-3 py-3 text-[10px] leading-[1.55] text-[#718073]"><LockKeyhole size={14} className="mt-0.5 shrink-0 text-[#609068]" /><p><strong className="font-semibold text-[#49634c]">Protected by escrow.</strong> The reward is captured in PayPal Sandbox now and sent to the freelancer only after the AI review passes.</p></div>
                {fundingError && <p role="alert" className="rounded-lg bg-[#fff1ef] px-3 py-2 text-[10px] font-medium text-[#aa5149]">{fundingError}</p>}
                <div className="flex items-center justify-between gap-3 pt-1">
                  <button type="button" onClick={closeFunding} className="rounded-lg px-3 py-2 text-[11px] font-semibold text-[#79847b] hover:bg-[#f4f6f2]">Cancel</button>
                  <button type="submit" disabled={creating} className="inline-flex items-center gap-2 rounded-[10px] bg-[#173a29] px-4 py-2.5 text-[11px] font-bold text-white shadow-sm transition hover:bg-[#24513a] disabled:cursor-wait disabled:opacity-70">{creating ? <LoaderCircle size={14} className="animate-spin" /> : <ArrowRight size={14} />} Create & continue</button>
                </div>
              </form>
            ) : fundingBounty ? (
              <div>
                <div className="rounded-[15px] border border-[#e8ece6] bg-[#fafbf9] p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0"><p className="text-[9px] font-bold uppercase tracking-[0.12em] text-[#88938a]">Bounty to fund</p><h3 className="mt-1.5 truncate text-[14px] font-semibold text-[#293b2f]">{fundingBounty.title}</h3><p className="mt-1 text-[10px] text-[#89938a]">Paying {fundingBounty.freelancerEmail}</p></div>
                    <p className="shrink-0 text-[20px] font-semibold tracking-[-0.04em] text-[#244a32]">{formatCurrency(fundingBounty.reward)}</p>
                  </div>
                </div>
                <div className="mt-4">
                  {paypalClientReady ? (
                    <>
                      <p className="mb-2 text-center text-[9px] font-semibold uppercase tracking-[0.1em] text-[#9aa39b]">Secure PayPal Sandbox checkout</p>
                      {fundingBusy && <div className="mb-2 flex items-center justify-center gap-2 text-[10px] text-[#748078]"><LoaderCircle size={13} className="animate-spin" /> Waiting for PayPal…</div>}
                      <div className={fundingBusy ? "pointer-events-none opacity-60" : ""}>
                        <PayPalButtons
                          style={{ layout: "vertical", shape: "rect", label: "pay", height: 44, tagline: false }}
                          forceReRender={[fundingBounty.id, fundingBounty.reward]}
                          createOrder={createCheckoutOrder}
                          onApprove={async (data) => { await captureCheckoutOrder(data.orderID); }}
                          onCancel={() => { setFundingBusy(false); setFundingError("Checkout was cancelled. Your draft is saved; you can resume funding at any time."); }}
                          onError={(error) => { setFundingBusy(false); setFundingError(error instanceof Error ? error.message : "PayPal checkout could not load. Check your Sandbox client ID."); }}
                        />
                      </div>
                    </>
                  ) : (
                    <div className="rounded-xl border border-dashed border-[#d9e3d7] bg-[#f5f9f3] p-4 text-center">
                      <CreditCard size={20} className="mx-auto text-[#668b68]" />
                      <p className="mt-2 text-[11px] font-semibold text-[#405c44]">Connect PayPal Sandbox to publish</p>
                      <p className="mx-auto mt-1 max-w-[330px] text-[10px] leading-4 text-[#849085]">Add <code className="rounded bg-white px-1 py-0.5 text-[#536851]">NEXT_PUBLIC_PAYPAL_CLIENT_ID</code> and the server PayPal credentials to your environment, then reload.</p>
                      <button type="button" onClick={closeFunding} className="mt-3 rounded-lg border border-[#dce5d9] bg-white px-3 py-2 text-[10px] font-semibold text-[#59725b]">Save draft and close</button>
                    </div>
                  )}
                </div>
                {fundingError && <p role="alert" className="mt-3 rounded-lg bg-[#fff2ef] px-3 py-2 text-[10px] leading-4 text-[#a55047]">{fundingError}</p>}
                <div className="mt-4 flex items-center justify-between border-t border-[#eef0ed] pt-3">
                  <button type="button" onClick={() => { setCreateStage("details"); setFundingBounty(null); setFundingError(""); }} className="text-[10px] font-semibold text-[#7b877d] hover:text-[#355440]">← Edit bounty details</button>
                  <span className="flex items-center gap-1 text-[9px] text-[#9aa39a]"><LockKeyhole size={10} /> Sandbox checkout</span>
                </div>
              </div>
            ) : null}
          </div>
        </Modal>
      )}

      {submissionBounty && (
        <Modal title="Submit completed work" subtitle={`AI will compare your delivery with the original brief. A score of 80+ releases the payout.`} onClose={closeSubmission} size="max-w-[620px]">
          <div className="px-5 pb-6 pt-5 sm:px-7">
            <div className="rounded-[14px] border border-[#e8ece6] bg-[#fafbf9] p-3.5">
              <div className="flex items-center justify-between gap-3"><p className="text-[9px] font-bold uppercase tracking-[0.12em] text-[#8a958c]">Task brief</p><span className="text-[11px] font-semibold text-[#4b664f]">{formatCurrency(submissionBounty.reward)}</span></div>
              <h3 className="mt-1.5 text-[13px] font-semibold text-[#293b2f]">{submissionBounty.title}</h3>
              <p className="mt-2 max-h-[100px] overflow-y-auto whitespace-pre-wrap text-[10px] leading-[1.65] text-[#78847a]">{submissionBounty.requirements}</p>
            </div>

            {submissionBounty.status === "revision_needed" && submissionBounty.aiFeedback && !reviewResult && (
              <div className="mt-3 rounded-[12px] border border-[#f0dfc9] bg-[#fff9ef] p-3.5">
                <div className="flex items-center gap-2 text-[10px] font-bold text-[#a56735]"><Sparkles size={13} /> AI feedback · score {submissionBounty.aiScore ?? 0}/100</div>
                <p className="mt-1.5 whitespace-pre-wrap text-[10px] leading-[1.6] text-[#896e53]">{submissionBounty.aiFeedback}</p>
              </div>
            )}

            {reviewResult && (
              <div className={`mt-3 rounded-[13px] border p-3.5 ${reviewResult.passed ? reviewResult.bounty.status === "paid" ? "border-[#cfe4d4] bg-[#f0f8f1]" : "border-[#f0d6cb] bg-[#fff5f1]" : "border-[#f0dfc9] bg-[#fff9ef]"}`}>
                <div className="flex items-center justify-between gap-3">
                  <div className={`flex items-center gap-2 text-[11px] font-bold ${reviewResult.passed && reviewResult.bounty.status === "paid" ? "text-[#39764d]" : "text-[#a56835]"}`}>
                    {reviewResult.passed && reviewResult.bounty.status === "paid" ? <CheckCircle2 size={15} /> : <Sparkles size={14} />}
                    {reviewResult.passed ? reviewResult.bounty.status === "paid" ? "Approved · payout sent" : "Approved · payout needs attention" : "Revision requested"}
                  </div>
                  <span className={`text-[13px] font-bold ${reviewResult.bounty.aiScore !== null && reviewResult.bounty.aiScore >= 80 ? "text-[#39764d]" : "text-[#a56835]"}`}>{reviewResult.bounty.aiScore ?? 0}<span className="ml-0.5 text-[9px] font-medium text-[#969d95]">/100</span></span>
                </div>
                <p className="mt-2 whitespace-pre-wrap text-[10px] leading-[1.65] text-[#69776c]">{reviewResult.bounty.aiFeedback}</p>
                {reviewResult.bounty.status === "paid" && <p className="mt-2 break-all border-t border-[#dcecdf] pt-2 font-mono text-[9px] text-[#54765a]">PayPal payout batch: {reviewResult.bounty.paypalPayoutBatchId}</p>}
                {reviewResult.error && <p className="mt-2 text-[10px] font-medium text-[#ad5148]">Payout error: {reviewResult.error}</p>}
                {!reviewResult.passed && <p className="mt-2 text-[9px] font-medium text-[#a27847]">Update your work below, then submit a revision for another review.</p>}
              </div>
            )}

            {(!reviewResult || !reviewResult.passed) && (
              <form onSubmit={reviewSubmission} className="mt-4">
                <label className="block"><FieldLabel>Your submission</FieldLabel><textarea required maxLength={20000} rows={6} value={submissionText} onChange={(event) => { setSubmissionText(event.target.value); if (reviewResult && !reviewResult.passed) setReviewResult(null); }} placeholder="Describe what you delivered, include links, and explain how it meets the requirements…" className="form-field min-h-[142px] resize-y py-2.5 leading-5" /></label>
                <div className="mt-2 flex items-center justify-between text-[9px] text-[#9ba49c]"><span>Be specific. The AI judge only sees this submission and the brief.</span><span>{submissionText.length}/20,000</span></div>
                <div className="mt-4 flex items-center justify-between gap-3">
                  <button type="button" onClick={closeSubmission} className="rounded-lg px-3 py-2 text-[10px] font-semibold text-[#7d887f] hover:bg-[#f4f6f2]">Close</button>
                  <button type="submit" disabled={reviewing || !submissionText.trim()} className="inline-flex items-center gap-2 rounded-[10px] bg-[#173a29] px-4 py-2.5 text-[10px] font-bold text-white transition hover:bg-[#24513a] disabled:cursor-not-allowed disabled:opacity-60">
                    {reviewing ? <><LoaderCircle size={13} className="animate-spin" /> AI is reviewing…</> : <><Sparkles size={13} /> Submit to AI judge</>}
                  </button>
                </div>
              </form>
            )}
            {reviewResult?.passed && reviewResult.bounty.status === "paid" && <div className="mt-4 text-right"><button type="button" onClick={closeSubmission} className="rounded-[10px] bg-[#173a29] px-4 py-2.5 text-[10px] font-bold text-white hover:bg-[#24513a]">Done</button></div>}
          </div>
        </Modal>
      )}

      {briefBounty && (
        <Modal title={briefBounty.status === "payout_failed" ? "Payout needs attention" : "Bounty details"} subtitle={briefBounty.title} onClose={() => setBriefBounty(null)} size="max-w-[560px]">
          <div className="space-y-4 px-5 pb-6 pt-5 sm:px-7">
            <div className="flex items-center justify-between gap-3"><StatusBadge status={briefBounty.status} /><span className="text-[17px] font-semibold tracking-[-0.04em] text-[#244a32]">{formatCurrency(briefBounty.reward)}</span></div>
            <div><FieldLabel>Requirements</FieldLabel><p className="whitespace-pre-wrap rounded-xl border border-[#e9ede7] bg-[#fafbf9] p-3.5 text-[11px] leading-[1.7] text-[#657267]">{briefBounty.requirements}</p></div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl bg-[#f6f8f5] p-3"><p className="text-[9px] font-bold uppercase tracking-[0.1em] text-[#909a91]">Freelancer PayPal</p><p className="mt-1.5 break-all text-[10px] font-medium text-[#405346]">{briefBounty.freelancerEmail}</p></div>
              <div className="rounded-xl bg-[#f6f8f5] p-3"><p className="text-[9px] font-bold uppercase tracking-[0.1em] text-[#909a91]">PayPal capture ID</p><p className="mt-1.5 break-all font-mono text-[9px] text-[#647268]">{briefBounty.paypalCaptureId || "Not captured yet"}</p></div>
            </div>
            {briefBounty.aiFeedback && <div className="rounded-xl border border-[#f0dfc9] bg-[#fff9ef] p-3.5"><p className="text-[10px] font-bold text-[#9c6e38]">AI review · {briefBounty.aiScore}/100</p><p className="mt-1.5 whitespace-pre-wrap text-[10px] leading-[1.6] text-[#806c52]">{briefBounty.aiFeedback}</p></div>}
            {briefBounty.payoutError && <p role="alert" className="rounded-xl border border-[#efd1ce] bg-[#fff3f1] p-3 text-[10px] leading-[1.55] text-[#a64d45]">{briefBounty.payoutError}</p>}
            {briefBounty.status === "payout_failed" && (
              <div className="flex justify-end gap-2 pt-1">
                <button type="button" onClick={() => setBriefBounty(null)} className="rounded-lg px-3 py-2 text-[10px] font-semibold text-[#7d887f] hover:bg-[#f4f6f2]">Close</button>
                <button type="button" disabled={retryingId === briefBounty.id} onClick={() => void retryPayout(briefBounty)} className="inline-flex items-center gap-2 rounded-[10px] bg-[#173a29] px-4 py-2.5 text-[10px] font-bold text-white hover:bg-[#24513a] disabled:opacity-60">
                  {retryingId === briefBounty.id ? <LoaderCircle size={13} className="animate-spin" /> : <CreditCard size={13} />} Retry sandbox payout
                </button>
              </div>
            )}
          </div>
        </Modal>
      )}

      {receiptBounty && (
        <Modal title="Payout receipt" subtitle="A verifiable record of work approved and paid through VeriPay AI." onClose={() => setReceiptBounty(null)} size="max-w-[540px]">
          <div className="px-5 pb-6 pt-5 sm:px-7">
            <div className="rounded-[16px] bg-[#173a29] p-5 text-white">
              <div className="flex items-start justify-between gap-3"><div><p className="text-[9px] font-bold uppercase tracking-[0.13em] text-[#afc4b1]">Paid & completed</p><p className="mt-1 text-[26px] font-semibold tracking-[-0.055em]">{formatCurrency(receiptBounty.reward)} <span className="text-[11px] font-medium text-[#b4c7b7]">USD</span></p></div><span className="grid h-9 w-9 place-items-center rounded-xl bg-[#b5d69f]/15 text-[#c2dfa9]"><BadgeCheck size={19} /></span></div>
              <div className="mt-4 border-t border-white/10 pt-3"><p className="text-[9px] text-[#adc1b0]">For</p><p className="mt-1 text-[12px] font-semibold">{receiptBounty.title}</p></div>
            </div>
            <div className="mt-4 space-y-2.5">
              <div className="flex items-center justify-between gap-3"><span className="text-[10px] text-[#89948b]">Freelancer</span><span className="break-all text-right text-[10px] font-medium text-[#415246]">{receiptBounty.freelancerEmail}</span></div>
              <div className="flex items-center justify-between gap-3"><span className="shrink-0 text-[10px] text-[#89948b]">AI quality score</span><span className="text-[10px] font-bold text-[#3c8053]">{receiptBounty.aiScore ?? "—"}<span className="ml-0.5 font-medium text-[#98a198]">/100</span></span></div>
              {receiptBounty.aiSummary && <div className="rounded-xl bg-[#f5f8f4] p-3 text-[10px] leading-[1.6] text-[#68766b]">{receiptBounty.aiSummary}</div>}
              <ReceiptId label="PayPal capture" value={receiptBounty.paypalCaptureId} onCopy={copyText} />
              <ReceiptId label="PayPal payout batch" value={receiptBounty.paypalPayoutBatchId} onCopy={copyText} prominent />
            </div>
            <div className="mt-5 flex justify-end"><button type="button" onClick={() => setReceiptBounty(null)} className="rounded-[10px] border border-[#e5e9e3] bg-white px-4 py-2 text-[10px] font-semibold text-[#4a5b4d] hover:bg-[#f6f8f4]">Close receipt</button></div>
          </div>
        </Modal>
      )}

      {notice && (
        <div role="status" className={`fixed bottom-4 right-4 z-[70] flex max-w-[min(92vw,420px)] items-center gap-2.5 rounded-[12px] border px-4 py-3 text-[11px] font-medium shadow-[0_10px_35px_rgba(18,40,28,.14)] ${notice.kind === "success" ? "border-[#d4e5d4] bg-white text-[#426c48]" : "border-[#efd7d2] bg-white text-[#9e4e45]"}`}>
          {notice.kind === "success" ? <CheckCircle2 size={15} /> : <CircleHelp size={15} />}{notice.message}
          <button type="button" onClick={() => setNotice(null)} className="ml-1 text-current opacity-60 hover:opacity-100" aria-label="Dismiss message"><X size={13} /></button>
        </div>
      )}
    </div>
  );
}

function ReceiptId({ label, value, onCopy, prominent = false }: { label: string; value: string | null; onCopy: (value: string) => void; prominent?: boolean }) {
  return (
    <div className={`rounded-xl border px-3 py-2.5 ${prominent ? "border-[#d8e7d9] bg-[#f1f7f0]" : "border-[#edf0eb] bg-[#fbfcfa]"}`}>
      <div className="flex items-center justify-between gap-3"><span className="text-[9px] font-semibold text-[#7e8a80]">{label}</span>{value && <button type="button" onClick={() => onCopy(value)} aria-label={`Copy ${label} ID`} className="text-[#7e8c7f] hover:text-[#315d3a]"><Copy size={12} /></button>}</div>
      <p className="mt-1 break-all font-mono text-[9px] leading-4 text-[#536257]">{value || "Not available"}</p>
    </div>
  );
}

export default function Dashboard() {
  const paypalClientId = process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID;
  const workspace = <DashboardWorkspace paypalClientReady={Boolean(paypalClientId)} />;
  if (!paypalClientId) return workspace;

  return (
    <PayPalScriptProvider
      options={{
        clientId: paypalClientId,
        currency: "USD",
        intent: "capture",
        components: "buttons",
      }}
    >
      {workspace}
    </PayPalScriptProvider>
  );
}
